// using JS Document API
document.getElementById("demo").innerHTML = "Demo of Flask with AJAX!";

// using JQuery
$(document).ready( function () {
    $.ajax({
        type: "GET",
        dataType: "json",
        data: 'AustinZipCodes',
        crossOrigin: true,
        url: "/ajax",
        success: function (data) {
            console.log(data['zips'])

            // build the rows from each response element
            $.each(data['zips'], function(i, data) {
                var body = "<tr>";
                body += "<td>" + data.id + "</td>";
                body += "<td>" + data.zip_code + "</td>";
                body += "<td>" + data.population + "</td>";
                body += "</tr>";
                $( "#dtable tbody" ).append(body);
            });

            /*DataTables instantiation.*/
            $( "#dtable" ).DataTable();
        },
        error: function (request, status, error) {
            alert(error)
            alert(request.responseText);
        }
    });
});