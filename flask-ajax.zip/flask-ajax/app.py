from flask import Flask, render_template
import json


app = Flask(__name__, template_folder='./templates')

@app.route("/")
def index():
     return render_template("index.html")

@app.route('/ajax')
def hello_world(name=None):
    str = {'zips': [
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        {'id': '01', 'zip_code': '78681', 'population': '50,606'},
        {'id': '02', 'zip_code': '78701', 'population': '6,841'},
        {'id': '03', 'zip_code': '78702', 'population': '21,334'},
        ]
   }

    res = json.dumps(str)
    return res

if __name__ == '__main__':
    app.run()